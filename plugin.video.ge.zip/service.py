import xbmc, xbmcaddon, xbmcgui, xbmcvfs, urllib.request, json, os, random, time

addon = xbmcaddon.Addon()

# Setup Local Persistence File Path (TV Reboot Safe)
profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not os.path.exists(profile_path):
    os.makedirs(profile_path)
data_store_file = os.path.join(profile_path, 'data_usage.json')

# 1. Non-Blocking Watermark Manager
class WatermarkOverlay:
    def __init__(self):
        self.labels = []
        self.win_ids = [10000, 12005, 10004, 10025]  # Home, FullScreenVideo, Programs, Videos
        
        for win_id in self.win_ids:
            try:
                lbl = xbmcgui.ControlLabel(
                    40, 40, 550, 200, "", 
                    textColor='0xFFFFFF00', # Yellow Color
                    font='font13'
                )
                xbmcgui.Window(win_id).addControl(lbl)
                self.labels.append((win_id, lbl))
            except Exception as e:
                xbmc.log(f"GE Watermark Add Warning ({win_id}): {e}", level=xbmc.LOGWARNING)

    def update_text(self, user_id, remaining_display, usage_rate_str, is_locked=False, lock_time_left=0, is_offline=False):
        if is_locked:
            lock_mins = int(lock_time_left // 60)
            text = (
                "[COLOR red][B]GANPATII ENTERPRISE[/B][/COLOR]\n"
                f"[COLOR red]STATUS: LOCKED (DATA EXHAUSTED / 12.20MB LEFT)[/COLOR]\n"
                f"REMAINING LOCK: {lock_mins} MINS\n"
                f"ID: {user_id}"
            )
        elif is_offline:
            text = (
                "[COLOR red][B]GANPATII ENTERPRISE[/B][/COLOR]\n"
                f"[COLOR red]STATUS: NETWORK OFFLINE[/COLOR]\n"
                f"ID: {user_id}"
            )
        else:
            text = (
                "[B]GANPATII ENTERPRISE[/B]\n"
                f"{remaining_display} LEFT\n"
                f"USAGE: {usage_rate_str}\n"
                f"ID: {user_id}"
            )
        
        for _, lbl in self.labels:
            try:
                lbl.setLabel(text)
            except:
                pass

    def cleanup(self):
        for win_id, lbl in self.labels:
            try:
                xbmcgui.Window(win_id).removeControl(lbl)
            except:
                pass

# Local Storage Functions
def load_saved_used_bytes():
    if os.path.exists(data_store_file):
        try:
            with open(data_store_file, 'r') as f:
                saved = json.load(f)
                return saved.get('used_bytes', 0)
        except:
            return 0
    return 0

def save_used_bytes(bytes_count):
    try:
        with open(data_store_file, 'w') as f:
            json.dump({'used_bytes': bytes_count}, f)
    except Exception as e:
        xbmc.log(f"GE Save Error: {e}", level=xbmc.LOGWARNING)

def format_usage_5s(bytes_count):
    if bytes_count < 1024 * 1024:
        kb = bytes_count / 1024.0
        return f"-{kb:.2f}KB/5S"
    else:
        mb = bytes_count / (1024.0 * 1024.0)
        return f"-{mb:.2f}MB/5S"

def monitor():
    xbmc.log("GE Agent: Monitoring Started (Persistence + 12.20MB Lock Limit)", level=xbmc.LOGINFO)
    mon = xbmc.Monitor()
    player = xbmc.Player()
    
    last_status = "none"
    overlay = WatermarkOverlay()

    # Load saved data from TV storage
    total_downloaded_bytes = load_saved_used_bytes()
    
    lock_until_time = 0
    failed_checks = 0
    was_playing = False

    while not mon.abortRequested():
        current_time = time.time()
        
        # --- Video Playback Finish -> Open TV Guide ---
        if was_playing and not player.isPlaying():
            was_playing = False
            xbmc.log("GE Agent: Video Playback Completed -> Opening TV Guide", level=xbmc.LOGINFO)
            xbmc.executebuiltin('ActivateWindow(TVGuide)')
        elif player.isPlaying():
            was_playing = True

        # --- 1. Check Lock Status ---
        if current_time < lock_until_time:
            time_left = lock_until_time - current_time
            phone = addon.getSetting("user_phone") or "XXXXXXXXXXX"
            overlay.update_text(phone, "12.20MB", "LOCKED", is_locked=True, lock_time_left=time_left)
            
            if player.isPlaying():
                player.stop()
                
            if mon.waitForAbort(5):
                break
            continue

        # --- 2. Fetch Data from GitHub ---
        data = None
        bytes_this_5s = 0
        
        try:
            req = urllib.request.Request(
                "https://raw.githubusercontent.com/rohanjaiawal1-code/ge-services-by-g-home/main/users.json",
                headers={'User-Agent': 'Mozilla/5.0'}
            )
            with urllib.request.urlopen(req, timeout=15) as url:
                raw_data = url.read()
                data = json.loads(raw_data.decode())
                
                bytes_this_5s = len(raw_data)
                total_downloaded_bytes += bytes_this_5s
                save_used_bytes(total_downloaded_bytes)  # Persistent Save
                failed_checks = 0
        except Exception as e:
            failed_checks += 1
            xbmc.log(f"GE Network Error ({failed_checks}/3): {e}", level=xbmc.LOGWARNING)
            if failed_checks >= 3:
                current_status = "offline"
            else:
                current_status = last_status

        # Default quota from GitHub (if not specified, default to 2000GB)
        github_total_gb = 2000.0
        if data:
            phone = addon.getSetting("user_phone")
            username = addon.getSetting("user_name")
            
            users_dict = data.get('users', {})
            if phone in users_dict and users_dict[phone].get('username') == username:
                current_status = users_dict[phone].get('status', 'error').strip().lower()
                github_total_gb = float(users_dict[phone].get('total_gb', 2000.0))
            else:
                current_status = "error"
        elif failed_checks >= 3:
            current_status = "offline"

        # --- 3. Calculate Remaining MB/GB ---
        total_allowed_bytes = github_total_gb * (1024.0 ** 3)
        remaining_bytes = total_allowed_bytes - total_downloaded_bytes
        remaining_mb = remaining_bytes / (1024.0 * 1024.0)

        # --- 4. 12.20 MB Lock Logic ---
        if remaining_mb <= 12.20:
            xbmc.log("GE Agent: Remaining data dropped to 12.20MB! Locking for 2 Hours.", level=xbmc.LOGWARNING)
            lock_until_time = time.time() + 7200  # 2 Hours Lock
            player.stop()
            continue

        # Format Remaining Display
        if remaining_mb > 1024:
            rem_gb = remaining_mb / 1024.0
            remaining_display = f"{rem_gb:.2f} GB"
        else:
            remaining_display = f"{remaining_mb:.2f} MB"

        usage_rate_str = format_usage_5s(bytes_this_5s)
        user_id_display = addon.getSetting("user_phone") if addon.getSetting("user_phone") else "XXXXXXXXXXX"
        
        if current_status == "offline":
            overlay.update_text(user_id_display, remaining_display, usage_rate_str, is_offline=True)
        else:
            overlay.update_text(user_id_display, remaining_display, usage_rate_str)

        # --- 5. Handle Status Actions ---
        if current_status != last_status:
            xbmc.log(f"GE Agent Switching: {last_status} -> {current_status}", level=xbmc.LOGINFO)
            
            if current_status == 'active':
                player.stop()
                playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playlist.clear()
                
                welcome_vids = data['videos'].get('welcome', [])
                if welcome_vids:
                    playlist.add(welcome_vids[0])
                
                ads_list = data['videos'].get('ads', [])
                if ads_list:
                    selected_ads = random.sample(ads_list, min(len(ads_list), 2))
                    for ad_url in selected_ads:
                        playlist.add(ad_url)
                
                trial_vids = data['videos'].get('trial', [])
                if trial_vids:
                    playlist.add(trial_vids[0])
                
                player.play(playlist)
                last_status = 'active'
            
            elif current_status in ['expired', 'error']:
                player.stop()
                err_vids = data.get('videos', {}).get(current_status, [])
                if err_vids:
                    xbmc.executebuiltin(f'PlayMedia("{err_vids[0]}")')
                    xbmc.executebuiltin("PlayerControl(RepeatAll)")
                last_status = current_status
            
            elif current_status == 'offline':
                xbmcgui.Dialog().notification("GE Premium", "Network Offline", xbmcgui.NOTIFICATION_WARNING, 3000)
                last_status = current_status

        if mon.waitForAbort(5):
            break

    overlay.cleanup()

if __name__ == '__main__':
    monitor()