import xbmc
import xbmcaddon
import time
import os
import urllib.request
import random
import json
import socket
import threading

# ==========================================
# 🔴 CONFIGURATION: GITHUB RAW JSON URL
# ==========================================
GITHUB_JSON_URL = "https://raw.githubusercontent.com/rohanjaiawal1-code/ge-services-by-g-home/refs/heads/main/users.json"

# Storage setup for auto-saved local videos
ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmc.translatePath(ADDON.getAddonInfo('path'))

LOCAL_VIDEOS = {
    "welcome": os.path.join(ADDON_PATH, "local_welcome.mp4"),
    "ads": os.path.join(ADDON_PATH, "local_ads.mp4"),
    "expired": os.path.join(ADDON_PATH, "local_expired.mp4"),
    "offline": os.path.join(ADDON_PATH, "local_offline.mp4")
}

def get_device_id():
    try:
        hostname = socket.gethostname()
        if hostname: return str(hostname).strip().lower()
    except: pass
    return "unknown_user"

def fetch_remote_data():
    try:
        nocache_url = f"{GITHUB_JSON_URL}?t={int(time.time())}"
        req = urllib.request.Request(nocache_url, headers={'User-Agent': 'Mozilla/5.0', 'Cache-Control': 'no-cache'})
        response = urllib.request.urlopen(req, timeout=5)
        return json.loads(response.read().decode('utf-8'))
    except: return None

def check_user_status(data):
    if not data or "users" not in data: return "offline"
    device_id = get_device_id()
    try:
        users_clean = {k.strip().lower(): v.strip().lower() for k, v in data["users"].items()}
        return users_clean.get(device_id, "expired")
    except: return "expired"

def get_video_target(data, category):
    """ Pehle local download file check karega, nahi toh online HLS link dega """
    if os.path.exists(LOCAL_VIDEOS[category]) and os.path.getsize(LOCAL_VIDEOS[category]) > 1000:
        return LOCAL_VIDEOS[category]
    
    try:
        if data and "videos" in data and category in data["videos"]:
            links = data["videos"][category]
            if links: return random.choice(links)
    except: pass
    return ""

def background_download_engine(data):
    """ Cloud se videos ko background me automatic download karke store karta hai """
    if not data or "videos" not in data: return
    
    headers = {'User-Agent': 'Mozilla/5.0'}
    for category, local_path in LOCAL_VIDEOS.items():
        try:
            links = data["videos"].get(category, [])
            if not links: continue
            url = links[0]
            
            # Agar file pehle se downloaded hai toh dobara download nahi karega
            if os.path.exists(local_path) and os.path.getsize(local_path) > 1000:
                continue
                
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=15) as response:
                with open(local_path, 'wb') as f:
                    f.write(response.read())
        except:
            pass

def lock_navigation_loop():
    """ Enforced Lock Screen for Expired/Offline states """
    while not xbmc.Monitor().waitForAbort(1):
        data = fetch_remote_data()
        status = check_user_status(data)
        
        if status == "active":
            xbmc.Player().stop()
            break 
            
        if not xbmc.Player().isPlaying():
            category = "offline" if status == "offline" else "expired"
            play_target = get_video_target(data, category)
            
            if play_target:
                xbmc.Player().play(play_target)
                xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")
                
        if not xbmc.getCondVisibility("Window.IsVisible(fullscreenvideo)"):
            xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")
            
        time.sleep(2)

def run_main_workflow():
    data = fetch_remote_data()
    status = check_user_status(data)
    
    # Background download thread shuru karein taaki loop na atke
    if status != "offline":
        threading.Thread(target=background_download_engine, args=(data,)).start()
        
    if status != "active":
        lock_navigation_loop()
        data = fetch_remote_data()
        
    # Welcome Video
    welcome_target = get_video_target(data, "welcome")
    if welcome_target:
        xbmc.Player().play(welcome_target)
        xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")
        for _ in range(20):
            if xbmc.Monitor().waitForAbort(1): return
            xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")
            time.sleep(1)
        xbmc.Player().stop()

    # Ads Video
    ad_target = get_video_target(data, "ads")
    if ad_target:
        xbmc.Player().play(ad_target)
        xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")
        for _ in range(60):
            if xbmc.Monitor().waitForAbort(1): return
            xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")
            time.sleep(1)
        xbmc.Player().stop()

    xbmc.executebuiltin("ActivateWindow(FavouritesBrowser)")

time.sleep(4)
run_main_workflow()